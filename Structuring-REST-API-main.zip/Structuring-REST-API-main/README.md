# Structuring-REST-API
This repository contains two projects that demonstrate the implementation of a RESTful API using Node.js, Express.js, MongoDB (with Mongoose), and the MVC pattern, alongside the EJS template engine for dynamic views.
